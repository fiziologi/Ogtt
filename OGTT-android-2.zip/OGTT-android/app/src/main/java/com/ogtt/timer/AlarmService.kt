package com.ogtt.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class AlarmService : Service() {

    companion object {
        const val CHANNEL = "ogtt_alarm"
        const val NOTIF_ID = 42
        private const val TIMEOUT_MS = 10 * 60 * 1000L

        @Volatile
        var ringing = false
        var current: AlarmService? = null
        var onStopped: (() -> Unit)? = null
    }

    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var currentIdx = 0
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { stopRinging() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        current = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val idx = intent?.getIntExtra("idx", 1) ?: 1
        currentIdx = idx
        val p = Scheduler.prefs(this)
        createChannel()
        val notification = buildNotification(idx, p.getInt("n", 2), p.getInt("base", 0))
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        if (!ringing) {
            ringing = true
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ogtt:alarm")
                wake?.acquire(TIMEOUT_MS)
            } catch (_: Exception) {
            }
            try {
                player = Sound.player(
                    this,
                    p.getString("sound", "bell") ?: "bell",
                    p.getInt("volume", 70),
                    true
                )
                player?.start()
            } catch (_: Exception) {
            }
            try {
                val v = getSystemService(Vibrator::class.java)
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                @Suppress("DEPRECATION")
                v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 300, 1500), 0), attrs)
            } catch (_: Exception) {
            }
        }
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, TIMEOUT_MS)
        return START_NOT_STICKY
    }

    fun stopRinging() {
        handler.removeCallbacks(timeout)
        cleanup()
        val p = Scheduler.prefs(this)
        p.edit().putInt("ackedUpTo", maxOf(p.getInt("ackedUpTo", 0), currentIdx)).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        onStopped?.invoke()
    }

    private fun cleanup() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        try { getSystemService(Vibrator::class.java)?.cancel() } catch (_: Exception) {}
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        ringing = false
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeout)
        cleanup()
        if (current === this) current = null
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Odběr krve", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setShowBadge(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(idx: Int, n: Int, base: Int): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val launch = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP

        // Tap on the notification: stop sound and open the app
        val ack = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_ACK).addFlags(launch),
            flags
        )
        // Full-screen intent (screen off / locked): only show the app, do not stop sound
        val ring = PendingIntent.getActivity(
            this, 3,
            Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_RING).addFlags(launch),
            flags
        )
        val stop = PendingIntent.getBroadcast(
            this, 4,
            Intent(this, AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_STOP),
            flags
        )

        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Čas na odběr krve")
            .setContentText("Odběr ${idx + base} z ${n + base}")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(ack)
            .setDeleteIntent(stop)
            .setFullScreenIntent(ring, true)
            .addAction(0, "Odběr hotov", stop)
            .build()
    }
}
