package com.ogtt.timer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    companion object {
        const val ACTION_ACK = "com.ogtt.timer.ACK"
        const val ACTION_RING = "com.ogtt.timer.RING"
    }

    private lateinit var web: WebView
    private var pageReady = false
    private var previewPlayer: MediaPlayer? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyRingFlags(intent)

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#FDEFE3"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()   // enables alert()/confirm() dialogs
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                handleIntent(intent)
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        if (Scheduler.prefs(this).getBoolean("active", false)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        AlarmService.onStopped = { js("window.nativeAck&&window.nativeAck()") }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                moveTaskToBack(true)
            }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyRingFlags(intent)
        if (pageReady) handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (pageReady) js("window.nativeSync&&window.nativeSync()")
    }

    override fun onDestroy() {
        AlarmService.onStopped = null
        previewPlayer?.release()
        previewPlayer = null
        web.removeJavascriptInterface("Android")
        super.onDestroy()
    }

    private fun applyRingFlags(i: Intent?) {
        if (i?.action == ACTION_RING) {
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }
        }
    }

    private fun handleIntent(i: Intent?) {
        when (i?.action) {
            ACTION_ACK -> {
                AlarmService.current?.stopRinging()
                js("window.nativeAck&&window.nativeAck()")
            }
            ACTION_RING -> js("window.nativeSync&&window.nativeSync()")
        }
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun playPreview(key: String, vol: Int) {
        try {
            previewPlayer?.release()
            previewPlayer = null
            val mp = Sound.player(this, key, vol, false) ?: return
            mp.setOnCompletionListener {
                it.release()
                if (previewPlayer === it) previewPlayer = null
            }
            previewPlayer = mp
            mp.start()
        } catch (_: Exception) {
        }
    }

    /** Functions callable from the page as window.Android.* */
    inner class Bridge {
        @JavascriptInterface
        fun schedule(json: String) {
            val o = JSONObject(json)
            val startTs = o.getLong("startTs")
            val arr = o.getJSONArray("offsets")
            val offsets = List(arr.length()) { arr.getInt(it) }
            Scheduler.cancelAll(this@MainActivity)
            Scheduler.prefs(this@MainActivity).edit()
                .putBoolean("active", true)
                .putLong("startTs", startTs)
                .putString("preset", o.getString("preset"))
                .putInt("base", o.getInt("base"))
                .putInt("n", offsets.size)
                .putString("offsets", offsets.joinToString(","))
                .putString("sound", o.getString("sound"))
                .putInt("volume", o.getInt("volume"))
                .putInt("ackedUpTo", 0)
                .apply()
            Scheduler.scheduleAll(this@MainActivity, startTs, offsets)
            runOnUiThread { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }

        @JavascriptInterface
        fun cancel() {
            Scheduler.cancelAll(this@MainActivity)
            Scheduler.prefs(this@MainActivity).edit().putBoolean("active", false).apply()
            runOnUiThread {
                AlarmService.current?.stopRinging()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun ack() {
            runOnUiThread { AlarmService.current?.stopRinging() }
        }

        @JavascriptInterface
        fun isRinging(): Boolean = AlarmService.ringing

        @JavascriptInterface
        fun getAckedUpTo(): Int = Scheduler.prefs(this@MainActivity).getInt("ackedUpTo", 0)

        @JavascriptInterface
        fun setSound(key: String, volume: Int) {
            Scheduler.prefs(this@MainActivity).edit()
                .putString("sound", key)
                .putInt("volume", volume)
                .apply()
        }

        @JavascriptInterface
        fun preview(key: String, volume: Int) {
            runOnUiThread { playPreview(key, volume) }
        }

        @JavascriptInterface
        fun getState(): String {
            val p = Scheduler.prefs(this@MainActivity)
            if (!p.getBoolean("active", false)) return ""
            return JSONObject()
                .put("active", true)
                .put("startTs", p.getLong("startTs", 0L))
                .put("preset", p.getString("preset", "grav"))
                .put("offsets", JSONArray().also { arr ->
                    (p.getString("offsets", "") ?: "").split(",")
                        .filter { it.isNotBlank() }
                        .forEach { arr.put(it.trim().toInt()) }
                })
                .put("sound", p.getString("sound", "bell"))
                .put("volume", p.getInt("volume", 70))
                .toString()
        }
    }
}
