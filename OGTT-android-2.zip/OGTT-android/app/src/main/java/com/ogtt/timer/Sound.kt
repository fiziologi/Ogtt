package com.ogtt.timer

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

object Sound {
    /** Player on the ALARM audio stream: uses alarm volume, plays even if media volume is muted. */
    fun player(c: Context, key: String, vol: Int, loop: Boolean): MediaPlayer? {
        val id = c.resources.getIdentifier("s_$key", "raw", c.packageName)
        if (id == 0) return null
        val mp = MediaPlayer()
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        val afd = c.resources.openRawResourceFd(id)
        mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
        afd.close()
        mp.isLooping = loop
        val v = vol.coerceIn(0, 100) / 100f
        mp.setVolume(v, v)
        mp.prepare()
        return mp
    }
}
