package com.ogtt.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_STOP = "com.ogtt.timer.STOP"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Scheduler.ACTION_ALARM -> {
                val svc = Intent(context, AlarmService::class.java)
                    .putExtra("idx", intent.getIntExtra("idx", 1))
                ContextCompat.startForegroundService(context, svc)
            }
            ACTION_STOP -> AlarmService.current?.stopRinging()
        }
    }
}
