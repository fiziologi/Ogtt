package com.ogtt.timer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences

object Scheduler {
    const val ACTION_ALARM = "com.ogtt.timer.ALARM"

    fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("ogtt", Context.MODE_PRIVATE)

    private fun alarmIntent(c: Context, idx: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .setAction(ACTION_ALARM)
            .putExtra("idx", idx)
        return PendingIntent.getBroadcast(
            c, 1000 + idx, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val n = prefs(c).getInt("n", 0)
        for (i in 1..n) am.cancel(alarmIntent(c, i))
    }

    /** setAlarmClock: exact, works in Doze, shows the alarm icon in the status bar. */
    fun scheduleAll(c: Context, startTs: Long, offsetsMin: List<Int>) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val now = System.currentTimeMillis()
        for ((index, minutes) in offsetsMin.withIndex()) {
            val at = startTs + minutes * 60000L
            if (at > now) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), alarmIntent(c, index + 1))
            }
        }
    }
}
